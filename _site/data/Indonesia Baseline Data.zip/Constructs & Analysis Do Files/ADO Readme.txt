The ADO file in this folder (igrowup_restricted.ado) is necessary to run the caregiver constructs.
The WHO released this ADO file in 2007 and can be found here

http://www.who.int/childgrowth/software/en/